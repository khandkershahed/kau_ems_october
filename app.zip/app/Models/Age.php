<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Age extends Model
{
    /** @use HasFactory<\Database\Factories\AgeFactory> */
    use HasFactory;
    
    protected $fillable = ['age'];
}
