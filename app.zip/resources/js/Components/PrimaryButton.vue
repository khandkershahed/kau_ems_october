<template>
    <button
        class="inline-flex items-center rounded-md border border-transparent bg-green-600 px-4 py-2 text-xs font-semibold uppercase tracking-widest text-white transition duration-150 ease-in-out hover:bg-green-500 focus:bg-green-500 focus:outline-none focus:ring-2 focus:ring-green-500 focus:ring-offset-2 active:bg-green-700 dark:bg-green-600 dark:text-white dark:hover:bg-green-500 dark:focus:bg-green-500 dark:focus:ring-offset-gray-800 dark:active:bg-green-700"
    >
        <slot />
    </button>
</template>
