<script setup>
import ApplicationLogo from '@/Components/ApplicationLogo.vue';
import ThemeToggle from '@/Components/ThemeToggle.vue';
import { useThemeStore } from '@/stores/theme';
import { onMounted } from 'vue';
import { Link } from '@inertiajs/vue3';

const themeStore = useThemeStore();
onMounted(() => {
    themeStore.initTheme();
});
</script>

<template>
    <div class="relative flex min-h-screen flex-col items-center justify-center p-4 sm:p-6 overflow-hidden">
        <!-- Abstract Full Page SVG Background -->
        <div class="fixed inset-0 -z-10 bg-slate-50 dark:bg-gray-900 transition-colors duration-300">
            <!-- Top Wave -->
            <svg class="absolute top-0 left-0 w-full h-auto text-green-500/10 dark:text-green-900/20" viewBox="0 0 1440 320" preserveAspectRatio="none">
                <path fill="currentColor" d="M0,96L48,112C96,128,192,160,288,160C384,160,480,128,576,122.7C672,117,768,139,864,165.3C960,192,1056,224,1152,224C1248,224,1344,192,1392,176L1440,160L1440,0L1392,0C1344,0,1248,0,1152,0C1056,0,960,0,864,0C768,0,672,0,576,0C480,0,384,0,288,0C192,0,96,0,48,0L0,0Z"></path>
            </svg>
            
            <!-- Bottom Wave -->
            <svg class="absolute bottom-0 left-0 w-full h-auto text-emerald-500/10 dark:text-emerald-900/20" viewBox="0 0 1440 320" preserveAspectRatio="none">
                <path fill="currentColor" d="M0,224L48,213.3C96,203,192,181,288,186.7C384,192,480,224,576,213.3C672,203,768,149,864,122.7C960,96,1056,96,1152,112C1248,128,1344,160,1392,176L1440,192L1440,320L1392,320C1344,320,1248,320,1152,320C1056,320,960,320,864,320C768,320,672,320,576,320C480,320,384,320,288,320C192,320,96,320,48,320L0,320Z"></path>
            </svg>

            <!-- Decorative Ambient Glows -->
            <div class="absolute top-1/4 left-1/4 h-64 w-64 rounded-full bg-green-400/20 mix-blend-multiply blur-[80px] dark:bg-green-700/20 dark:mix-blend-screen"></div>
            <div class="absolute bottom-1/4 right-1/4 h-64 w-64 rounded-full bg-emerald-400/20 mix-blend-multiply blur-[80px] dark:bg-emerald-700/20 dark:mix-blend-screen"></div>
        </div>

        <div class="absolute top-4 right-4 z-20">
            <ThemeToggle />
        </div>

        <div class="z-10 mb-8 flex flex-col items-center">
            <Link href="/" class="group">
                <ApplicationLogo
                    class="h-20 w-25 rounded-sm  fill-current text-gray-500"
                />
            </Link>
        </div>

        <div
            class="z-10 w-full overflow-hidden bg-white/90 backdrop-blur-xl px-6 py-8 shadow-[0_8px_30px_rgb(0,0,0,0.12)] sm:max-w-md sm:rounded-3xl dark:bg-gray-800/90 dark:shadow-[0_8px_30px_rgb(0,0,0,0.3)] border border-white/40 dark:border-gray-700/50 transition-all duration-300"
        >
            <slot />
        </div>
    </div>
</template>
